# SimplePOS — CodeIgniter 4 POS Foundations

A four-page Point-of-Sale foundations project for **IT0049 / TFA1**. It contains a landing page, an about page, a customer directory, and a staff directory.

| Page | URL | Controller | Data |
| --- | --- | --- | --- |
| Home | `/` | `Pages::index` | Introductory content |
| About | `/about` | `Pages::about` | Project information |
| Customer Accounts | `/customers` | `Customers::index` | Five fictional customers in a PHP array |
| User Accounts | `/users` | `Users::index` | Five fictional staff members in a PHP array |

The routes are in `app/Config/Routes.php`. The controller methods are in `app/Controllers/`, and the four page views are in `app/Views/`. Both account pages display records with `foreach`.

## Start locally

1. Install **PHP 8.2 or later** with the `intl` and `mbstring` extensions, plus **Composer 2**.
2. Open a terminal **inside this extracted project folder** and run:

   ```bash
   composer install
   php spark serve
   ```

3. Open `http://localhost:8080/`, then check `/about`, `/customers`, and `/users`.

The included `.env` sets `app.baseURL = 'http://localhost:8080/'` and removes `index.php` from URLs. If `.env` is missing, copy the included `env` file to `.env` before starting. Stop the local server with **Ctrl+C**.

**How the starter works:** `composer install` downloads the real `codeigniter4/framework` package. Its post-install script copies standard CodeIgniter application configuration from the Composer package to `app/` while keeping the four-page project's own routes, controllers, and views. This avoids storing a second, duplicate copy of CodeIgniter's stock configuration in the repository. The generated `vendor/` directory is intentionally excluded from source control. Run `composer install` before starting the application.

## Publish the source to GitHub

The ZIP must be **extracted**. Create a new public GitHub repository named `simplepos-codeigniter4` at <https://github.com/new> (leave the "Add a README" option off). In the repository select **Add file → Upload files**, and upload the *contents* of this project folder, including `app/`, `public/`, `scripts/`, `docker/`, `writable/`, `tests/`, `.github/`, `composer.json`, `Dockerfile`, `render.yaml`, and `README.md`. Commit the upload. A repository containing only the ZIP is not a source-code repository. The included GitHub Actions workflow builds the Docker image and checks all four pages after the upload.

You can instead push this project with Git if you use GitHub Desktop or a terminal. The repository URL you submit will have the form `https://github.com/YOUR-USERNAME/simplepos-codeigniter4`.

## Deploy a working PHP site

GitHub Pages cannot run PHP. The included `Dockerfile` and `render.yaml` prepare this application for a **Render web service**:

1. Sign in to <https://dashboard.render.com/> and connect your GitHub account.
2. Choose **New → Web Service**, select the `simplepos-codeigniter4` repository, choose the **Docker** runtime and **Free** plan, and deploy. Leave the Dockerfile path as `./Dockerfile`. You can also choose **New → Blueprint** to use the provided `render.yaml`.
3. When deployment reports **Live**, open the assigned `https://...onrender.com` address. Visit `/`, `/about`, `/customers`, and `/users` on that address; copy the base address for submission.

The Docker image installs PHP dependencies using Composer and serves `public/` through Apache on port `10000`. At startup on Render, its startup script uses Render's `RENDER_EXTERNAL_URL` to set the real `app.baseURL` and switches CodeIgniter to production mode. A free Render service may sleep when unused and take a little while to wake.

### Submission text

```text
GitHub repository: https://github.com/YOUR-USERNAME/simplepos-codeigniter4
Hosted application: https://YOUR-RENDER-URL.onrender.com
```

Replace both examples with the **actual URLs you created and opened**. Never submit the example addresses as if they were live.

## Database export

**Not applicable in this module.** The assignment's page requirements explicitly say to use PHP arrays as a temporary data source and not to connect a database. There is no database to export. The five fictional records for each directory are defined directly in `Customers.php` and `Users.php`.

## Current scope

This foundation displays sample records. It does not yet create sales, persist data, register users, or authenticate staff. Those features can be added in later modules.
