<?php

declare(strict_types=1);

// Composer supplies the official framework. Copy its standard application
// configuration on installation, keeping this project's custom files intact.
$root   = dirname(__DIR__);
$source = $root . '/vendor/codeigniter4/framework/app';
$target = $root . '/app';

if (! is_dir($source)) {
    fwrite(STDERR, "CodeIgniter's application template was not found at {$source}.\n");
    exit(1);
}

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
);

foreach ($iterator as $file) {
    if (! $file->isFile()) {
        continue;
    }

    $relative = substr($file->getPathname(), strlen($source) + 1);

    // This module replaces the default welcome page and controller.
    if (in_array(str_replace('\\', '/', $relative), ['Controllers/Home.php', 'Views/welcome_message.php'], true)) {
        continue;
    }

    $destination = $target . '/' . $relative;

    if (file_exists($destination)) {
        continue;
    }

    if (! is_dir(dirname($destination)) && ! mkdir(dirname($destination), 0775, true) && ! is_dir(dirname($destination))) {
        fwrite(STDERR, "Unable to create " . dirname($destination) . "\n");
        exit(1);
    }

    if (! copy($file->getPathname(), $destination)) {
        fwrite(STDERR, "Unable to install {$destination}.\n");
        exit(1);
    }
}

echo "CodeIgniter starter configuration is ready.\n";
