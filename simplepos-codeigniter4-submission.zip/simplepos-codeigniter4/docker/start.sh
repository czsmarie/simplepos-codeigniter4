#!/bin/sh
set -eu

# Render supplies the real public URL at runtime. Write its actual address to
# CodeIgniter's .env so navigation works even when Render changes the hostname.
if [ -n "${RENDER_EXTERNAL_URL:-}" ]; then
    printf "CI_ENVIRONMENT = production\napp.baseURL = '%s/'\napp.indexPage = ''\n" "${RENDER_EXTERNAL_URL%/}" > /var/www/html/.env
fi

exec apache2-foreground
