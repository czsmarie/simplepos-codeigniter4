<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index(): string
    {
        return view('layouts/header', ['title' => 'Home', 'activePage' => 'home'])
            . view('pages/home')
            . view('layouts/footer');
    }

    public function about(): string
    {
        return view('layouts/header', ['title' => 'About', 'activePage' => 'about'])
            . view('pages/about')
            . view('layouts/footer');
    }
}
