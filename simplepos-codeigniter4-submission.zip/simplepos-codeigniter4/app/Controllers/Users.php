<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index(): string
    {
        // Temporary data source for this module. No database is used.
        $users = [
            ['username' => 'admin.lee', 'full_name' => 'Camille Lee', 'role' => 'Administrator'],
            ['username' => 'cashier.ana', 'full_name' => 'Ana Flores', 'role' => 'Cashier'],
            ['username' => 'cashier.noel', 'full_name' => 'Noel Ramos', 'role' => 'Cashier'],
            ['username' => 'manager.joy', 'full_name' => 'Joy Bautista', 'role' => 'Manager'],
            ['username' => 'inventory.pao', 'full_name' => 'Paolo Lim', 'role' => 'Inventory Staff'],
        ];

        return view('layouts/header', ['title' => 'User Accounts', 'activePage' => 'users'])
            . view('users/index', ['users' => $users])
            . view('layouts/footer');
    }
}
