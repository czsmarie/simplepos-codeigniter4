<?php

namespace App\Controllers;

use CodeIgniter\Controller;

abstract class BaseController extends Controller
{
    /** @var list<string> */
    protected $helpers = ['url'];
}
