<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index(): string
    {
        // Temporary data source for this module. No database is used.
        $customers = [
            ['full_name' => 'Alyssa Reyes', 'email' => 'alyssa.reyes@example.com', 'phone' => '0917-000-0101'],
            ['full_name' => 'Marco Santos', 'email' => 'marco.santos@example.com', 'phone' => '0917-000-0102'],
            ['full_name' => 'Bianca Cruz', 'email' => 'bianca.cruz@example.com', 'phone' => '0917-000-0103'],
            ['full_name' => 'Daniel Garcia', 'email' => 'daniel.garcia@example.com', 'phone' => '0917-000-0104'],
            ['full_name' => 'Sofia Mendoza', 'email' => 'sofia.mendoza@example.com', 'phone' => '0917-000-0105'],
        ];

        return view('layouts/header', ['title' => 'Customer Accounts', 'activePage' => 'customers'])
            . view('customers/index', ['customers' => $customers])
            . view('layouts/footer');
    }
}
