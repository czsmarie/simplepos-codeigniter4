<section class="page-banner page-banner-compact">
    <div class="container page-banner-inner">
        <div><span class="eyebrow"><span class="eyebrow-line"></span> PEOPLE / 01</span><h1>Customer <em>accounts.</em></h1></div>
        <p>A straightforward directory of the people who shop with you. The records below are fictional sample data.</p>
    </div>
</section>
<section class="directory-section">
    <div class="container">
        <div class="directory-heading"><div><span class="eyebrow eyebrow-dark">DIRECTORY</span><h2>All customers</h2></div><span class="count-pill"><?= count($customers) ?> RECORDS</span></div>
        <div class="table-wrap">
            <table>
                <caption class="visually-hidden">Customer accounts with full name, email address, and phone number</caption>
                <thead><tr><th scope="col">FULL NAME</th><th scope="col">EMAIL ADDRESS</th><th scope="col">PHONE NUMBER</th></tr></thead>
                <tbody>
                <?php foreach ($customers as $customer): ?>
                    <tr>
                        <td><span class="person-cell"><span class="avatar" aria-hidden="true"><?= esc(strtoupper(substr($customer['full_name'], 0, 1))) ?></span><strong><?= esc($customer['full_name']) ?></strong></span></td>
                        <td><a href="mailto:<?= esc($customer['email'], 'attr') ?>"><?= esc($customer['email']) ?></a></td>
                        <td><?= esc($customer['phone']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="table-footnote"><span class="status-dot"></span> SAMPLE DATA ONLY <span class="footnote-line"></span> Database integration comes in a future module.</p>
    </div>
</section>
