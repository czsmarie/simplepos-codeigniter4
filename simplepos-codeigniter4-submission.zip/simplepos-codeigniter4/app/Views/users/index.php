<section class="page-banner page-banner-compact">
    <div class="container page-banner-inner">
        <div><span class="eyebrow"><span class="eyebrow-line"></span> PEOPLE / 02</span><h1>User <em>accounts.</em></h1></div>
        <p>The team behind the counter. See each sample staff member's username, full name, and role.</p>
    </div>
</section>
<section class="directory-section">
    <div class="container">
        <div class="directory-heading"><div><span class="eyebrow eyebrow-dark">DIRECTORY</span><h2>All users</h2></div><span class="count-pill"><?= count($users) ?> RECORDS</span></div>
        <div class="table-wrap">
            <table>
                <caption class="visually-hidden">User accounts with username, full name, and role</caption>
                <thead><tr><th scope="col">USERNAME</th><th scope="col">FULL NAME</th><th scope="col">ROLE</th></tr></thead>
                <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><span class="username"><?= esc($user['username']) ?></span></td>
                        <td><span class="person-cell"><span class="avatar avatar-alt" aria-hidden="true"><?= esc(strtoupper(substr($user['full_name'], 0, 1))) ?></span><strong><?= esc($user['full_name']) ?></strong></span></td>
                        <td><span class="role-pill"><?= esc($user['role']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="table-footnote"><span class="status-dot"></span> SAMPLE DATA ONLY <span class="footnote-line"></span> Roles are labels; authentication is outside this module.</p>
    </div>
</section>
