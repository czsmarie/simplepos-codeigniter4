    </main>
    <footer class="site-footer">
        <div class="container footer-inner">
            <span class="footer-brand">simplepos<span>.</span></span>
            <span>Built with CodeIgniter 4 · Static sample data</span>
            <span>IT0049 / TFA1</span>
        </div>
    </footer>
</div>
</body>
</html>
