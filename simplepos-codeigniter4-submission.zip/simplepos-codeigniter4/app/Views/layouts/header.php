<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#142222">
    <title><?= esc($title) ?> · SimplePOS</title>
    <link rel="stylesheet" href="<?= esc(base_url('assets/css/site.css'), 'attr') ?>">
</head>
<body>
<a class="skip-link" href="#main-content">Skip to content</a>
<div class="site-shell">
    <header class="site-header">
        <div class="container header-inner">
            <a class="brand" href="<?= esc(site_url('/'), 'attr') ?>" aria-label="SimplePOS home">
                <span class="brand-icon" aria-hidden="true"><span></span><span></span><span></span><span></span></span>
                <span>simple<span class="brand-accent">pos</span><span class="brand-dot">.</span></span>
            </a>
            <nav class="main-nav" aria-label="Main navigation">
                <a href="<?= esc(site_url('/'), 'attr') ?>" <?= $activePage === 'home' ? 'aria-current="page"' : '' ?>>Home</a>
                <a href="<?= esc(site_url('about'), 'attr') ?>" <?= $activePage === 'about' ? 'aria-current="page"' : '' ?>>About</a>
                <a href="<?= esc(site_url('customers'), 'attr') ?>" <?= $activePage === 'customers' ? 'aria-current="page"' : '' ?>>Customers</a>
                <a href="<?= esc(site_url('users'), 'attr') ?>" <?= $activePage === 'users' ? 'aria-current="page"' : '' ?>>Users</a>
            </nav>
            <span class="header-tag">POS FOUNDATIONS <span>01</span></span>
        </div>
    </header>
    <main id="main-content">
