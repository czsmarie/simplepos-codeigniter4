<section class="page-banner">
    <div class="container page-banner-inner">
        <div><span class="eyebrow"><span class="eyebrow-line"></span> THE PROJECT</span><h1>Small beginnings.<br><em>Solid foundations.</em></h1></div>
        <p>SimplePOS is a four-page learning project built with CodeIgniter 4. It shows how routes, controllers, and views come together.</p>
    </div>
</section>
<section class="content-section">
    <div class="container about-grid">
        <div class="about-aside"><span class="section-index">01 — ABOUT THIS BUILD</span><div class="about-mark" aria-hidden="true">s<span>p</span>.</div></div>
        <div class="about-body">
            <h2>Built for the first step.</h2>
            <p>This version introduces a landing page, an about page, a customer directory, and a staff directory. Each URL is mapped to a controller action, which passes information to a view for display.</p>
            <div class="about-list">
                <div><span class="list-number">01</span><div><h3>Routes</h3><p>Connect each of the four URLs to the right controller method.</p></div></div>
                <div><span class="list-number">02</span><div><h3>Controllers</h3><p>Prepare the page and keep sample customer and user records in PHP arrays.</p></div></div>
                <div><span class="list-number">03</span><div><h3>Views</h3><p>Render the pages and loop through each record to build the account tables.</p></div></div>
            </div>
            <div class="about-callout"><span class="status-dot"></span> No database yet. This module uses fictional sample records stored in PHP arrays.</div>
        </div>
    </div>
</section>
