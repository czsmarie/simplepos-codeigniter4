<section class="hero">
    <div class="container hero-grid">
        <div class="hero-copy">
            <span class="eyebrow"><span class="eyebrow-line"></span> YOUR STORE, ORGANIZED</span>
            <h1>A simpler start<br>for <em>every sale.</em></h1>
            <p>A clean foundation for managing the people behind your point of sale. Start with customer and staff records, all in one place.</p>
            <div class="hero-actions">
                <a class="button button-primary" href="<?= esc(site_url('customers'), 'attr') ?>">View customers <span aria-hidden="true">↗</span></a>
                <a class="button button-text" href="<?= esc(site_url('about'), 'attr') ?>">Explore the project <span aria-hidden="true">→</span></a>
            </div>
            <div class="hero-meta"><span class="status-dot"></span> FOUNDATION BUILD <span class="hero-meta-divider"></span> CODEIGNITER 4</div>
        </div>
        <div class="hero-art" aria-hidden="true">
            <div class="art-orbit art-orbit-one"></div>
            <div class="art-orbit art-orbit-two"></div>
            <div class="art-orbit art-orbit-three"></div>
            <div class="art-main-card">
                <div class="art-card-top"><span class="mini-logo">s<span>p</span>.</span><span class="art-spark">✳</span></div>
                <div class="art-card-bottom"><span>GOOD BUSINESS<br>STARTS HERE</span><span class="art-arrow">↗</span></div>
            </div>
            <span class="art-note art-note-top">01 / PEOPLE</span>
            <span class="art-note art-note-bottom">MADE FOR YOUR NEXT STEP</span>
        </div>
    </div>
</section>

<section class="feature-section" aria-labelledby="overview-heading">
    <div class="container">
        <div class="section-heading">
            <div><span class="eyebrow eyebrow-dark">THE WORKSPACE</span><h2 id="overview-heading">Everything in its place.</h2></div>
            <p>Four focused pages. A clear view of your customers and team. Ready to grow when the next module arrives.</p>
        </div>
        <div class="feature-grid">
            <a class="feature-card" href="<?= esc(site_url('customers'), 'attr') ?>">
                <div class="feature-card-top"><span class="feature-icon" aria-hidden="true">◯</span><span class="feature-number">01 / 02</span></div>
                <div><h3>Customer accounts</h3><p>Keep contact details together so you always know who you're serving.</p></div>
                <span class="feature-link">Explore customers <span aria-hidden="true">↗</span></span>
            </a>
            <a class="feature-card feature-card-alt" href="<?= esc(site_url('users'), 'attr') ?>">
                <div class="feature-card-top"><span class="feature-icon" aria-hidden="true">✳</span><span class="feature-number">02 / 02</span></div>
                <div><h3>User accounts</h3><p>Meet the staff behind the counter and see each person's role at a glance.</p></div>
                <span class="feature-link">Explore users <span aria-hidden="true">↗</span></span>
            </a>
        </div>
    </div>
</section>
