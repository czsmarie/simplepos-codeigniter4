CodeIgniter writes cache, log, session, and upload files below this directory.
The web server must be allowed to write here. The directories are included in source control.
