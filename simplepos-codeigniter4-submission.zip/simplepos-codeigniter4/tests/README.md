This directory is reserved for automated CodeIgniter tests in a future module.
